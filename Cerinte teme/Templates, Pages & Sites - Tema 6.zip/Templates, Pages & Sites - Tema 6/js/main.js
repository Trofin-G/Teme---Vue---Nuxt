"use strict";

var contractsHandler;

(function () {
  "use strict";

  var ContractsHandler = function ContractsHandler() {
    var self = this;
    var contractsArray = [];
    var sortContractsAarray = [];
    var filters = [];

    this.ready = function () {
      if (document.getElementById('contracts')) {
        this.handleDOM();
        this.handleEvents();
      }
    };

    this.handleDOM = function () {
      this.body = document.getElementsByTagName('body')[0];
      this.filters = document.getElementById('filters');
      this.closeMobileFilters = document.getElementById('closeFilters');
      this.openMobileFIlters = document.getElementById('openFilters');
      this.saveFilters = document.getElementById('saveFilters');
      this.resetFilters = document.getElementById('resetFilters');
      this.dropdownTrigger = document.querySelectorAll('.dropdown__trigger');
      this.searchContractsInput = document.querySelectorAll('.search-message');
      this.openSearchBt = document.getElementById('openSearch');
      this.searchForm = document.querySelector('.search-form__mobile');
      this.contractsList = document.querySelectorAll('.list');
      this.sortByDesktop = document.getElementById('sorByDesktop');
      this.sortByMobile = document.getElementById('sorByMobile');
      this.perPage = document.getElementById('perPage');
      this.contracts = document.querySelectorAll('.contract');
      this.checkboxes = document.querySelectorAll('.input__checkbox');
      this.activeFilters = document.getElementById('activeFilters');
    };

    this.handleEvents = function () {
      this.drawContracts(parseInt(this.perPage.value));
      this.contracts.forEach(function (contract) {
        sortContractsAarray.push(contract);
      }); // Filter contracts

      this.checkboxes.forEach(function (item) {
        item.addEventListener('change', function () {
          var checkedElts = document.querySelectorAll('input[type="checkbox"]:checked');
          filters = [];
          checkedElts.forEach(function (elt) {
            filters.push(elt.value);
          });
          self.activeFilters.innerHTML = checkedElts.length;
          self.contracts.forEach(function (contract) {
            // get the contract status
            var status = contract.dataset.status;
            var type = contract.dataset.type;
            contract.classList.add('d-none');

            if (filters.indexOf(status.toLowerCase()) !== -1 || filters.indexOf(type.toLowerCase()) !== -1) {
              contract.classList.add('d-block');
            } else {
              contract.classList.remove('d-block');
              contract.classList.add('d-none');
            }

            if (checkedElts.length === 0) {
              filters = [];
              contract.classList.remove('d-none');
              contract.classList.add('d-block');
            }
          }); // Reset search

          self.resetSearch(); // Reset select

          var select = document.querySelectorAll('.nice-select');
          select.forEach(function (el) {
            el.parentNode.removeChild(el);
          }); // init custom select

          inputsHandler.initCustomSelect();
        });
      }); // Sort contracts by new/old desktop

      this.sortByDesktop.addEventListener('change', function () {
        var value = this.value; // Reset search

        self.resetSearch();
        self.sortContracts(value, sortContractsAarray);
      }); // Sort contracts by new/old mobile

      this.sortByMobile.addEventListener('change', function () {
        var value = this.value; // Reset search

        self.resetSearch();
        self.sortContracts(value, sortContractsAarray);
      }); // Select how many contracts are displayed per page

      this.perPage.addEventListener('change', function () {
        var value = this.value; // Reset filters

        filters = [];
        self.contracts.forEach(function (contract) {
          contract.classList.remove('d-none', 'd-block');
        });
        self.checkboxes.forEach(function (item) {
          item.checked = false;
        }); // Reset search

        self.resetSearch();
        self.drawContracts(value);
      }); // Open mobile filters

      this.openMobileFIlters.addEventListener('click', function (e) {
        e.preventDefault();
        self.filters.classList.add('is-open');
      }); // Close mobile filters

      this.closeMobileFilters.addEventListener('click', function (e) {
        e.preventDefault();
        self.filters.classList.remove('is-open');
        self.checkboxes.forEach(function (item) {
          item.checked = false;
        });
      }); // Save mobile selected filters

      this.saveFilters.addEventListener('click', function (e) {
        e.preventDefault();
        self.filters.classList.remove('is-open');
      }); // Reset mobile selected filters

      this.resetFilters.addEventListener('click', function (e) {
        e.preventDefault();
        self.filters.classList.remove('is-open');
        filters = [];
        self.activeFilters.innerHTML = filters.length;
        self.contracts.forEach(function (contract) {
          contract.classList.remove('d-none');
          contract.classList.add('d-block');
        });
        self.checkboxes.forEach(function (item) {
          item.checked = false;
        });
      }); // Toggle dropdown filters

      this.dropdownTrigger.forEach(function (item) {
        item.addEventListener('click', function (e) {
          e.preventDefault();
          var collapse = this.nextElementSibling;
          collapse.classList.toggle('is-show');
        });
      });
      /**
       * Function to open the search input
       * for mobile
       */

      this.openSearchBt.addEventListener('click', function (e) {
        e.preventDefault();
        var searchFormInput = self.searchForm.querySelector('input');
        self.searchForm.classList.add('search-form__mobile--active');
        searchFormInput.focus();
      });
      /**
       * Function to listen the click event for body
       * if the click was made outside the target elements,
       * hide the search form
       */

      this.body.addEventListener('click', function (e) {
        if (e.target.getAttribute('id') === 'openSearch' || e.target.classList.contains('search-img') || e.target.classList.contains('search-message')) {
          return;
        } else {
          // hide the search form
          self.searchForm.classList.remove('search-form__mobile--active');
        }
      }); // loop through every input for search

      this.searchContractsInput.forEach(function (input) {
        // listen to "keyup" event
        input.addEventListener('keyup', function (e) {
          // set the input value;
          var value = e.target.value; // loop through every list o contracts

          self.contractsList.forEach(function (list) {
            // check if element is visible (doesn't have "display: none;" property)
            if (list.offsetParent) {
              // get all contracts
              var contracts = list.querySelectorAll('.contract');

              if (value) {
                // loop through every contracts
                contracts.forEach(function (contract) {
                  // get the company name element
                  var companyName = contract.querySelector('.contract__details--company'); // reset

                  contract.classList.remove('d-block');
                  contract.classList.remove('d-none');

                  if (companyName.innerHTML.toLowerCase().indexOf(value.toLowerCase()) !== -1) {
                    // show the filtered element
                    contract.classList.add('d-block');
                  } else {
                    // hide the other
                    contract.classList.add('d-none');
                  }
                });
              } else {
                // reset
                contracts.forEach(function (contract) {
                  contract.classList.remove('d-none');
                  contract.classList.add('d-block');
                });
              }
            }
          }); // Reset filters

          filters = [];
          self.checkboxes.forEach(function (item) {
            item.checked = false;
          });
        });
      });
    };
    /**
     * Draw contacts list
     * @param val
     */


    this.drawContracts = function (val) {
      if (val) {
        // loop through every contracts
        self.contracts.forEach(function (contract) {
          contract.classList.add('d-none');
          contractsArray.push(contract);
        });
        setTimeout(function () {
          contractsArray.slice(0, val).forEach(function (item) {
            item.classList.remove('d-none');
          });
        }, 100);
      }
    };
    /**
     * Sort contracts by series, company cui and company name
     * @param value
     * @param array
     */


    this.sortContracts = function (value, array) {
      if (value === "contractSeries") {
        array.sort(function (a, b) {
          return a.dataset.series.toLowerCase().localeCompare(b.dataset.series.toLowerCase());
        });
      }

      if (value === "companyCUI") {
        array.sort(function (a, b) {
          return +a.dataset.cui - +b.dataset.cui;
        });
      }

      if (value === "companyName") {
        array.sort(function (a, b) {
          return a.dataset.name.toLowerCase().localeCompare(b.dataset.name.toLowerCase());
        });
      }

      array.forEach(function (el) {
        self.contractsList.innerHtml = "";
        setTimeout(function () {
          self.contractsList[0].appendChild(el);
        }, 100);
      });
    }; // Reset search


    this.resetSearch = function () {
      self.searchContractsInput.forEach(function (input) {
        input.value = "";
      });
    };
  };

  contractsHandler = new ContractsHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    contractsHandler.ready();
  });
})();

var demoHandler;

(function () {
  "use strict";

  var DemoHandler = function DemoHandler() {
    var self = this;
    this.ibanLength = 24;
    this.romanianBanks = {
      "ABNA": "RBS BANK ROMANIA",
      "ARBL": "ANGLO ROMANIAN BANK",
      "BCUN": "NOVA BANK SA",
      "BCYP": "BANK OF CYPRUS ROMANIA",
      "BITR": "BANCA ITALO ROMENA",
      "BLOM": "BLOM BANK FRANCE S.A. PARIS SUC ROMANIA",
      "BPOS": "BANC POST SA",
      "BRDE": "BANCA ROMANA PENTRU DEZVOLTARE",
      "BREL": "LIBRA BANK S.A.",
      "BRMA": "BANCA ROMANEASCA",
      "BSEA": "EMPORIKI BANK ROMANIA S.A.",
      "BTRL": "BANCA TRANSILVANIA",
      "BUCU": "ALPHA BANK",
      "CAIX": "CAJA DE AHORROS Y PENSIONES BARCELONA",
      "CARP": "BANCA COMERCIALA CARPATICA",
      "CECE": "CEC BANK S.A.",
      "CITI": "CITIBANK ROMANIA",
      "CRCO": "BANCA CENTRALA COOPERATISTA CREDITCOOP",
      "CRDZ": "MKB ROMEXTERRA SA",
      "DABA": "Danske Bank Copenhagen",
      "DAFB": "BANK LEUMI ROMANIA S.A.",
      "DARO": "BANCA C.R. FIRENZE ROMANIA",
      "DPFA": "DEPFA BANK PLC DUBLIN SUC BUCURESTI",
      "EGNA": "MARFIN BANK ROMANIA S.A.",
      "ETHN": "NATIONAL BANK OF GREECE",
      "EXIM": "EXIMBANK",
      "FNNB": "CREDIT EUROPE BANK ROMANIA S.A.",
      "FRBU": "FRANKFURT BUCHAREST BANK",
      "FTSB": "FORTIS BANK SA NV BRUXELLES SUC BUCUREST",
      "HVBL": "HVB BANCA PENTRU LOCUINTE",
      "INGB": "ING BANK ROMANIA",
      "MILB": "BANCA MILLENIUM S.A.",
      "MIND": "ATE BANK ROMANIA S.A.",
      "MIRO": "PROCREDIT BANK",
      "NBOR": "BANCA NATIONALA A ROMANIEI",
      "OTPV": "OTP BANK ROMANIA S.A.",
      "PIRB": "PIRAEUS BANK ROMANIA",
      "PORL": "PORSCHE BANK",
      "RNCB": "BANCA COMERCIALA ROMANA",
      "ROIN": "ROMANIAN INTERNATIONAL BANK",
      "RZBL": "RAIFFEISEN BANCA PT LOCUINTE",
      "RZBR": "RAIFFEISEN BANK ROMANIA S.A.",
      "TRFD": "TRANSFOND SA",
      "UGBI": "GARANTIBANK INTERNATIONAL NV",
      "VBBU": "VOLKSBANK ROMANIA",
      "WBAN": "BANCA COMERCIALA INTESA SANPAOLO ROMANIA",
      "BCRL": "BCR BANCA PENTRU LOCUINTE S.A.",
      "TREZ": "TREZORERIA STATULUI",
      "BACX": "UNICREDIT TIRIAC BANK"
    };

    this.ready = function () {
      if (document.querySelectorAll('.gui').length !== 0) {
        this.handleDOM();
        this.handleEvents();
      }
    };

    this.handleDOM = function () {
      this.personType = document.getElementById('personType');
      this.ibanInput = document.querySelector('.check-bank');
      this.bankInput = document.querySelector('.bank');
    };

    this.handleEvents = function () {
      // listen to select input change
      this.personType.addEventListener('change', function (e) {
        // set the current selected value
        var value = e.target.value; // execute function to toggle visible fields

        self.toggleFields(value);
      }); // listen to input event

      this.ibanInput.addEventListener('input', function (e) {
        // set the current element
        var elt = e.target; // execute function to populate the input for bank name

        self.parseBankName(elt);
      });
    };
    /**
     * Function to toggle visible fields based on selected value
     * @param value
     */


    this.toggleFields = function (value) {
      // get all fields that have "data-type" attribute
      var allFields = document.querySelectorAll('[data-type]'); // loop through every field

      allFields.forEach(function (field) {
        // reset
        field.classList.add('d-none'); // look for matching elements/fields

        if (field.getAttribute('data-type') === value) {
          // show field
          field.classList.remove('d-none');
        }
      });
    };
    /**
     * Function to parse the bank name based on IBAN value
     * @param element
     */


    this.parseBankName = function (element) {
      // set the current element value
      var value = element.value.toUpperCase(); // get the error label element

      var labelError = element.nextElementSibling; // check the length of the input value to be the length of an IBAN

      if (value.length === self.ibanLength) {
        // get the chars from 4 to 8
        var bankCode = value.slice(4, 8);
        var bankName = '';

        if (this.romanianBanks[bankCode]) {
          // set bank name according to defined object
          bankName = this.romanianBanks[bankCode]; // set the value for the bank input

          this.bankInput.value = bankName; // reset

          element.classList.remove('input__text--invalid');
          labelError.classList.add('d-none');
        } else {
          // reset
          this.resetInput(this.bankInput, element, labelError);
        }
      } else {
        // reset
        this.resetInput(this.bankInput, element, labelError);
      }
    };
    /**
     * Function to reset the input, state and label
     * @param input
     * @param element
     * @param label
     */


    this.resetInput = function (input, element, label) {
      // reset the value for the bank input
      input.value = null; // add specific states on input an error label

      element.classList.add('input__text--invalid'); // show the error message

      label.classList.remove('d-none');
    };
  };

  demoHandler = new DemoHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    demoHandler.ready();
  });
})();

var documentsHandler;

(function () {
  "use strict";

  var DocumentsHandler = function DocumentsHandler() {
    var self = this;

    this.ready = function () {
      if (document.getElementById('documents')) {
        this.handleDOM();
        this.handleEvents();
      }
    };

    this.handleDOM = function () {
      this.inputFile = document.querySelectorAll('input[type="file"]');
    };

    this.handleEvents = function () {
      this.parseUploadFile();
    };
    /**
     * Function to parse the name of a uploaded file
     */


    this.parseUploadFile = function () {
      // Loop through each input of type file
      this.inputFile.forEach(function (item, index) {
        item.addEventListener('change', function (event) {
          if (!event || !event.target || !event.target.files || event.target.files.length === 0) {
            return;
          }

          var name = event.target.files[0].name; // get the name of the selected file

          var lastDot = name.lastIndexOf('.');
          var fileName = name.substring(0, lastDot); // get the file name

          var ext = name.substring(lastDot + 1); // get the file extension

          var parent = item.parentNode.parentNode;
          var sibling = parent.previousElementSibling;
          var fileNamePlace = sibling.querySelector('.item__name--file');
          fileNamePlace.textContent = fileName + '.' + ext;
        });
      });
    };
  };

  documentsHandler = new DocumentsHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    documentsHandler.ready();
  });
})();

var dynamicFieldsetsHandler;

(function () {
  "use strict";

  var DynamicFieldsetsHandler = function DynamicFieldsetsHandler() {
    var self = this;
    this.counter = 1;
    this.fieldsetTpl = "\n      <legend>Operator #<span class=\"operator-counter\">{{count}}</span></legend>\n\n      <div class=\"group\">\n\n          <!-- START:: Input type text -->\n          <div class=\"input input--sm\">\n              <label class=\"input__label\" for=\"operatorName[{{count}}]\">Nume operator</label>\n              <input type=\"text\" id=\"operatorName[{{count}}]\" class=\"input__text\" name=\"operatorName[{{count}}]\">\n          </div>\n          <!-- END:: Input type text -->\n\n          <!-- START:: Input type text -->\n          <div class=\"input input--sm\">\n              <label class=\"input__label\" for=\"operatorPosition[{{count}}]\">Functie operator</label>\n              <input type=\"text\" id=\"operatorPosition[{{count}}]\" class=\"input__text\" name=\"operatorPosition[{{count}}]\">\n          </div>\n          <!-- END:: Input type text -->\n\n          <!-- START:: Input type checkbox -->\n          <div class=\"input input--checkbox\">\n              <input type=\"checkbox\" class=\"input__checkbox\" name=\"operatorGdpr[{{count}}]\" id=\"operatorGdpr[{{count}}]\">\n              <label for=\"operatorGdpr[{{count}}]\">Acord GDPR</label>\n          </div>\n          <!-- END:: Input type checkbox -->\n\n          <!-- START:: Message -->\n          <div class=\"input\">\n              <label class=\"input__label\" for=\"operatorDetails[{{count}}]\">Detalii operator</label>\n              <textarea name=\"operatorDetails[{{count}}]\" id=\"operatorDetails[{{count}}]\" class=\"input__textarea\"></textarea>\n          </div>\n          <!-- END:: Message -->\n          \n           <div class=\"remove\">\n                <a href=\"#\" class=\"remove-fieldset bt bt--sm bt--fill\" data-target=\"{{count}}\">Sterge operator</a>\n            </div>\n\n      </div>\n\n";

    this.ready = function () {
      if (document.querySelectorAll('.multiple-fieldsets').length !== 0) {
        this.handleDOM();
        this.handleEvents();
      }
    };

    this.handleDOM = function () {
      this.body = document.querySelector('body');
      this.fieldsetsWrapper = document.querySelector('.multiple-fieldsets');
      this.addBtn = document.querySelector('.add .bt');
    };

    this.handleEvents = function () {
      // listen to click event
      this.addBtn.addEventListener('click', function (e) {
        e.preventDefault(); // incerment the counter

        self.counter++; // create new fieldset based on template and counter

        var newFieldset = self.stringToHTML(self.fieldsetTpl, self.counter); // append the new fieldset to wrapper

        self.fieldsetsWrapper.appendChild(newFieldset); // select the remove button from new created fieldset

        var removeButton = self.fieldsetsWrapper.querySelectorAll('.remove .bt');
        removeButton.forEach(function (item) {
          // listen to click event
          item.addEventListener('click', self.removeFieldset);
        });
        document.querySelectorAll('.operator-counter').forEach(function (elt, index) {
          elt.innerText = index + 1;
        });
      });
    };
    /**
     * Convert a template string into HTML DOM nodes
     * @param str
     * @param count
     * @returns {Element}
     */


    this.stringToHTML = function (str, count) {
      var fieldset = document.createElement('fieldset');
      fieldset.setAttribute('data-count', count);
      str = str.replace(/{{count}}/g, count);
      fieldset.innerHTML = str;
      return fieldset;
    };
    /**
     * Funtion to remove created fieldset based on "data-count" attribute
     * @param event
     */


    this.removeFieldset = function (event) {
      event.preventDefault();
      var dataTarget = event.target.getAttribute('data-target');
      var targetFieldset = document.querySelector('[data-count="' + dataTarget + '"]');
      self.fieldsetsWrapper.removeChild(targetFieldset);
      document.querySelectorAll('.operator-counter').forEach(function (elt, index) {
        elt.innerText = index + 1;
      });
    };
  };

  dynamicFieldsetsHandler = new DynamicFieldsetsHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    dynamicFieldsetsHandler.ready();
  });
})();

var inputsHandler;

(function () {
  "use strict";

  var InputsHandler = function InputsHandler() {
    var self = this;

    this.ready = function () {
      this.handleDOM();
      this.handleEvents();
    };

    this.handleDOM = function () {
      this.datePicker = document.querySelectorAll('.input__datepicker');
      this.customSelect = document.querySelectorAll('.input__select');
      this.inputFile = document.querySelectorAll('.input__file');
    };

    this.handleEvents = function () {
      // init datepicker
      this.initDatePicker(); // init custom select

      this.initCustomSelect();
      this.parseUploadFile();
    };
    /**
     * Function to initialize datepicker input
     */


    this.initDatePicker = function () {
      this.datePicker.forEach(function (item, index) {
        var config = {
          dateFormat: "d/m/Y"
        };
        var minDate = item.getAttribute('data-minDate'); // get the min date attribute

        var maxDate = item.getAttribute('data-maxDate'); // get the max date attribute

        if (minDate) {
          config.minDate = minDate === 'today' ? 'today' : new Date(minDate); // set the min date value
        }

        if (maxDate) {
          config.maxDate = maxDate === 'today' ? 'today' : new Date(maxDate); // set the max date value
        }

        item.flatpickr(config);
      });
    };
    /**
     * Function to initialize custom select input
     */


    this.initCustomSelect = function () {
      this.customSelect.forEach(function (item, index) {
        var options = {};
        var searchableAttr = item.getAttribute('data-searchable');
        var searchable = searchableAttr ? searchableAttr.toLowerCase() === 'true' : ''; // set searchable to Boolean value

        var placeholder = item.getAttribute('data-placeholder') ? item.getAttribute('data-placeholder') : ''; // set input for searching placeholder

        var defaultValue = item.getAttribute('data-default') ? item.getAttribute('data-default') : 'Selectează o opţiune'; // set default value of select

        if (searchable) {
          // make the select searchable
          options.searchable = true;
        } // init the custom select


        var niceSelectInstance = NiceSelect.bind(item, options); // set the placeholder value

        niceSelectInstance.placeholder = placeholder;
        var dropdown = niceSelectInstance.dropdown;
        var selectedElt = dropdown.querySelector('.current');
        var searchInput = dropdown.querySelector('input'); // set the default value for select

        selectedElt.innerHTML = defaultValue;

        if (searchInput) {
          // set placeholder attribute for search input
          searchInput.setAttribute('placeholder', placeholder);
        }
      });
    };
    /**
     * Function to parse the name of a uploaded file
     */


    this.parseUploadFile = function () {
      // Loop through each input of type file
      this.inputFile.forEach(function (item, index) {
        item.addEventListener('change', function (event) {
          if (!event || !event.target || !event.target.files || event.target.files.length === 0) {
            return;
          }

          var name = event.target.files[0].name; // get the name of the selected file

          var lastDot = name.lastIndexOf('.');
          var fileName = name.substring(0, lastDot); // get the file name

          var ext = name.substring(lastDot + 1); // get the file extension
          // select all siblings of input

          var inputSiblings = self.getSiblings(item); // loop through each sibling

          inputSiblings.forEach(function (sibling) {
            sibling.textContent = fileName + '.' + ext; // text shown according to the uploaded file
          });
        });
      });
    };
    /**
     * Function to get the siblings of an element
     * @param elem
     * @returns {Array}
     */


    this.getSiblings = function (elem) {
      // Setup siblings array and get the first sibling
      var siblings = [];
      var sibling = elem.parentNode.firstChild; // Loop through each sibling and push to the array

      while (sibling) {
        if (sibling.nodeType === 1 && sibling !== elem) {
          siblings.push(sibling);
        }

        sibling = sibling.nextSibling;
      }

      return siblings;
    };
  };

  inputsHandler = new InputsHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    inputsHandler.ready();
  });
})();

var layoutHandler;

(function () {
  "use strict";

  var LayoutHandler = function LayoutHandler() {
    var self = this;

    this.ready = function () {
      this.handleDOM();
      this.handleEvents();
    };

    this.handleDOM = function () {
      this.body = document.getElementsByTagName('body')[0];
      this.menuCollapse = document.getElementById('menuCollapse');
      this.menuToggle = document.getElementById('menuToggle');
    };

    this.handleEvents = function () {
      if (document.getElementById('ppHeader')) {
        // Open/close menu on mobile devices
        this.menuToggle.addEventListener('click', function (e) {
          e.preventDefault();
          this.classList.toggle('is-active');
          self.menuCollapse.classList.toggle('is-open');
          self.body.classList.toggle('menu-is-open');
        });
      }
    };
  };

  layoutHandler = new LayoutHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    layoutHandler.ready();
  });
})();

(function () {
  'use strict'; // Your custom JavaScript goes here
  // forEach prototype

  if (typeof NodeList !== "undefined" && NodeList.prototype && !NodeList.prototype.forEach) {
    NodeList.prototype.forEach = Array.prototype.forEach;
  }
})();

var messagesHandler;

(function () {
  "use strict";

  var MessagesHandler = function MessagesHandler() {
    var self = this;

    this.ready = function () {
      if (document.querySelectorAll('.messages__list').length !== 0) {
        this.handleDOM();
        this.handleEvents();
      }
    };

    this.handleDOM = function () {
      this.body = document.getElementsByTagName('body')[0];
      this.messageAsideMenu = document.querySelector('.messages__list aside');
      this.messagesTypeSelector = this.messageAsideMenu.querySelectorAll('input[name="messages"]');
      this.messagesTypeSelectorMobile = document.querySelector('select[name="messageTypes"]');
      this.messagesList = document.querySelectorAll('.list');
      this.searchMessageInput = document.querySelectorAll('.search-message');
      this.openSearchBt = document.getElementById('openSearch');
      this.searchForm = document.querySelector('.search-form__mobile');
    };

    this.handleEvents = function () {
      // loop through every tab (hidden input radio)
      this.messagesTypeSelector.forEach(function (elt) {
        // listen to change event
        elt.addEventListener('change', function (e) {
          // activate the specific tab
          self.parseActiveMessagesTab(e.currentTarget.value);
        });
      }); // listen to select change event

      this.messagesTypeSelectorMobile.addEventListener('change', function (e) {
        // activate the specific tab
        self.parseActiveMessagesTab(e.currentTarget.value);
      }); // loop through every input for search

      this.searchMessageInput.forEach(function (input) {
        // listen to "keyup" event
        input.addEventListener('keyup', function (e) {
          // set the input value;
          var value = e.target.value; // loop through every list o messages

          self.messagesList.forEach(function (list) {
            // check if element is visible (doesn't have "display: none;" property
            if (list.offsetParent) {
              // get all messages
              var messages = list.querySelectorAll('.list__message');

              if (value) {
                // loop through everry message
                messages.forEach(function (message) {
                  // get the subject element
                  var subject = message.querySelector('.subject'); // reset

                  message.classList.remove('d-block');
                  message.classList.remove('d-none');

                  if (subject.innerHTML.toLowerCase().indexOf(value.toLowerCase()) !== -1) {
                    // show the filtered element
                    message.classList.add('d-block');
                  } else {
                    // hide the other
                    message.classList.add('d-none');
                  }
                });
              } else {
                // reset
                messages.forEach(function (message) {
                  message.classList.remove('d-none');
                  message.classList.add('d-block');
                });
              }
            }
          });
        });
      });
      /**
       * Function to open the search input
       * for mobile
       */

      this.openSearchBt.addEventListener('click', function (e) {
        e.preventDefault();
        var searchFormInput = self.searchForm.querySelector('input');
        self.searchForm.classList.add('search-form__mobile--active');
        searchFormInput.focus();
      });
      /**
       * Function to listen the click event for body
       * if the click was made outside the target elements,
       * hide the search form
       */

      this.body.addEventListener('click', function (e) {
        if (e.target.getAttribute('id') === 'openSearch' || e.target.classList.contains('search-img') || e.target.classList.contains('search-message')) {
          return;
        } else {
          // hide the search form
          self.searchForm.classList.remove('search-form__mobile--active');
        }
      });
      /**
       * Function to toggle visible tab messages
       * @param value
       */

      this.parseActiveMessagesTab = function (value) {
        self.messagesList.forEach(function (listItem) {
          listItem.classList.remove('d-block');
        });
        document.querySelector('.' + value).classList.add('d-block');
      };
    };
  };

  messagesHandler = new MessagesHandler();
  document.addEventListener("DOMContentLoaded", function (event) {
    messagesHandler.ready();
  });
})();